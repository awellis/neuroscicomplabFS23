# Script für Uebung 2: Data Wrangling

# author: ___
# date: ___

# ---------------------------------------------------------------------------------------------------------------------
# INFORMATIONEN ZUR ÜBUNG

# Lesen Sie die Anweisungen zu Uebung 2 auf der Website: ___ .
# Speichern Sie Ihre Änderungen und laden Sie sie wie beschrieben hoch.

# Code & Kommentare:

# Kommentare werden mit `#`davor gekennzeichnet, so weiss `R`, dass dies Text und nicht ausführbarer Code ist.
# Verwenden Sie also vor jedem Kommentar ein #.
# Kommentieren Sie mit knappen, genauen Angaben. So weiss Ihr Peer Reviewer, was das Skript machen wird und was das Ziel des Codes ist.
# Überall wo ___ steht, müssen Sie das Fehlende einfügen.

# ---------------------------------------------------------------------------------------------------------------------

# Lade nötige library
library(tidyverse)


#### Daten Einlesen ####

# Pfad angeben in dem sich die Daten befinden

datadir <- ___

# ____
csv_files <- datadir |>
    list.files(pattern = "___",
               full.names = TRUE)

# File Liste anschauen
#___


# ___
# (wieso verwenden wir "contain"?)
data <- csv_files |>
    map(___,
        col_names = TRUE,
        col_select = c(contains("Pseudonym"), # id der Versuchsperson
                      contains("cue"), # ___
                      contains("direction"), # ___
                      contains("main_blocks_loop.thisN"), # ___
                      contains("dots_keyboard_response.keys"), # ___
                      contains("dots_keyboard_response.rt") # ___
                      )) |>
    list_rbind()

# Datensatz anschauen
___ |>
    slice_head(n = 20)

# ___
data  <- data |>
    filter(!is.na(main_blocks_loop.thisN)) |>
    select(-contains("practice_block_loop"))


#### Variablen Auswählen Und Umbenennen ####
# ___
data <- data |>
    select(ID = ___,
           trial = ____,
           cue,
           direction,
           response = ___,
           rt = ___)

# Datensatz anschauen
___ |>
    slice_head(n = 20)


#### Neue Variablen Erstellen ####

# ___
data <- data |>
    mutate(choice = if_else(response == "j", "right", "left"), #___
           response = if_else(choice == "right", 1, 0)) # ___

data <- data |>
    mutate(___ = as.numeric(choice == direction))

# Datensatz anschauen (kontrollieren Sie hier, ob die Variable "correct" richtig berechnet worden ist!)
___ |>
    slice_head(n = 20)


# ___
data <- data |>
    mutate(condition = case_when(cue == "none" ~ "neutral",
                                 cue == direction ~ "___",
                                 cue != direction ~ "___"))

# Datensatz anschauen (kontrollieren Sie hier, ob die Variable "condition" richtig eingefügt worden ist!)
___ |>
    slice_head(n = 20)

# Gesamtdatensatz speichern
data |> ___(file = "rdkdata_clean.csv")



#### Accuracy pro Bedingung berechnen ####

# ___
data <- data |>
    mutate(across(where(is.character), as_factor))


# ___
check <- data |>
    group_by(ID, condition) |>
    summarise(n_trials = n()) |>
    slice_head(n = 20)
View(check) # Fällt Ihnen was auf? ______

# ___
accuracy <- data |>
    group_by(ID, condition) |>
    summarise(N = n(),
              ncorrect = sum(correct),
              accuracy = mean(correct))
View(accuracy) # Fällt Ihnen was auf? ______


# Accuracy pro Bedingung:

overall_accuracy <- data |>
    group_by(___) |>
    summarise(___ = mean(___))

View(overall_accuracy)


# Accuracy in Bedingung "invalid": _____
# Accuracy in Bedingung "valid": _____
# Accuracy in Bedingung "neutral": _____



# Vor der Abgabe bitte folgende Checks durchführen:

# Dateiname mit Initialen ergänzen.

# Löschen Sie die Variablen im Workspace. Verwenden Sie dazu z.B. das “Besen”-Icon unter Environment oder nutzen Sie unter dem Reiter Session den Befehl Clear Workspace. Führen Sie danach das Skript nochmals von oben bis unten aus.

# Prüfen Sie, ob alle Pfade relativ sind, und nicht an Ihren Rechner gebunden sind.

# Prüfen Sie, ob alles gut und verständlich kommentiert ist.

# Prüfen Sie, ob Sie die 3 Werte für Accuracy pro Bedingung als Kommentar in das Skript geschrieben haben.
